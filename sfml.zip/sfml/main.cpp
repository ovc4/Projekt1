#include <SFML/Graphics.hpp>
#include <iostream>
#include <optional>

int main() {
    std::cout << "Program startuje..." << std::endl;

    sf::RenderWindow window(sf::VideoMode({800, 600}), "SFML 3.0.2 Test");

    sf::CircleShape circle(100.f);
    circle.setFillColor(sf::Color::Green);
    circle.setPosition(sf::Vector2f{350.f, 250.f}); // Poprawione dla SFML 3

    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
        }

        window.clear(sf::Color::Black);
        window.draw(circle);
        window.display();
    }

    std::cout << "Okno zostało zamknięte. Program kończy działanie." << std::endl;
    std::cout << "Naciśnij Enter, aby zakończyć..." << std::endl;
    std::cin.get();

    return 0;
}
